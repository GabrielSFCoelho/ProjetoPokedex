package br.com.up.pokedex.model

data class Type(
    val slot: Int,
    val type: PokemonType
)