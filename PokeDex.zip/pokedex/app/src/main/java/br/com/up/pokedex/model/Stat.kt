package br.com.up.pokedex.model

data class Stat(
    val base_stat: Int,
    val effort: Int,
    val stat: PokemonStat
)