package br.com.up.pokedex.model

data class PokemonAbility(
    val name: String,
    val url: String
)