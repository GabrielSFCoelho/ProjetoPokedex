package br.com.up.pokedex.model

data class PokemonStat(
    val name: String,
    val url: String
)